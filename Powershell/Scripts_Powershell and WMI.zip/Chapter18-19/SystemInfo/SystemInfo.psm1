﻿Import-Module C:\Scripts\Modules\SystemInfo/Win32OperatingSystem.cdxml -Force
Import-Module C:\Scripts\Modules\SystemInfo/Win32ComputerSystem.cdxml -Force
Update-FormatData -PrependPath C:\Scripts\Modules\SystemInfo/Win32OperatingSystem.format.ps1xml
Update-TypeData C:\Scripts\Modules\SystemInfo/Win32OperatingSystem.types.ps1xml