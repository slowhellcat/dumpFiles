﻿Import-Module ./Win32OperatingSystem.cdxml
Import-Module ./Win32ComputerSystem.cdxml
Update-FormatData -PrependPath ./Win32OperatingSystem.format.ps1xml
Update-TypeData ./Win32OperatingSystem.types.ps1xml