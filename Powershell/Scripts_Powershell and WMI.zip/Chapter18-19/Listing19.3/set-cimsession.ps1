﻿function set-cimsession {
[CmdletBinding()]
param (
 [string]$computername="$env:COMPUTERNAME"   
 )
BEGIN {
 $opt = New-CimSessionOption -Protocol DCOM  
}

PROCESS {
switch ($computername){
 "."         {$computername="$env:COMPUTERNAME" }
 "localhost" {$computername="$env:COMPUTERNAME" }
}

if (-not (Test-Connection -ComputerName $computername -Quiet -Count 1)){
  Throw "Computer: $($computername) could not be contacted"   
}

$twsman = Test-WSMan -ComputerName $computername -Authentication Default  
$pva = $twsman.ProductVersion -split ": "
$stack = $pva[-1]
Write-Debug $stack                        

switch ($stack){ 
 "2.0" {$ncs = New-CimSession -ComputerName $computername -SessionOption $opt }
 "3.0" {$ncs = New-CimSession -ComputerName $computername }
 default {Throw "Error - could not recognise WSMAN stack for $computer"}
}
$ncs 
} # end process
}
