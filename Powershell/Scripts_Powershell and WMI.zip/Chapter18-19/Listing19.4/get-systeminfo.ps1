﻿function get-systeminfo {
[CmdletBinding()]
param (
 [string]$computername="$env:COMPUTERNAME"
 )
BEGIN {
 Import-Module systeminfo –Force 
}

PROCESS {
switch ($computername){
 "."         {$computername="$env:COMPUTERNAME" }
 "localhost" {$computername="$env:COMPUTERNAME" }
}
if (-not (Test-Connection -ComputerName $computername -Quiet -Count 1)){
  Throw "Computer: $($computername) could not be contacted" 
}

if (-not(Test-Path -Path variable:\"cs_$computername")){ 
  New-Variable -Name "cs_$computername" `
  -Value (set-cimsession -computer $computername)
}

Get-Win32OperatingSystem `
-CimSession (Get-Variable -Name "cs_$computername").Value | 
Out-Default

Get-CimInstance -ClassName Win32_ComputerSystem `
-CimSession (Get-Variable -Name "cs_$computername").Value | 
Out-Default
} # end process
}
