﻿Import-Module ./Win32OperatingSystem.cdxml
Import-Module ./Win32ComputerSystem.cdxml